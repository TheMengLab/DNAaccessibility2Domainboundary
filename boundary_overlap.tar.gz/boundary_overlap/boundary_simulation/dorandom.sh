#!/bin/bash

delta=$1
winsize=$2
dir=$3


cat *[0-9]/random/dist_sort*.dat | sort -g | grep -v 10000 > test_random.dat
statenum=`nl test_random.dat | tail -n 1 | awk '{print $1}'`
targetcount=`cat test_random.dat | awk '{if($1<10.5) count++} END {print count}'`
totalcount=`cat ${dir}/*[0-9]/targetpeakid.dat | nl | tail -n 1 | awk '{print $1}'`
echo $targetcount $statenum $totalcount | awk '{print $1,$2,$3}' > statis_random.dat


cat statis_random.dat | awk '{print $1/$2}' > statis_random_ratio.dat
