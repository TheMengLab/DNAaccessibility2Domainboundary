#!/bin/bash


#identify the domain boundary of chromosome 1 from experimental Hi-C data
cd boundary_exp/boundarypos/chr1/
bash do.sh
cd ../../..


#calculate the overlap between domain boundaries separately obtained from simulated conformation ensemble and Hi-C data. file domain boundaries from simulated conformation ensemble of chromosome are presented as ./boundary_simulation/1/targetpeakid.dat
cd boundary_simulation
bash getoverlap.sh
cd ../
