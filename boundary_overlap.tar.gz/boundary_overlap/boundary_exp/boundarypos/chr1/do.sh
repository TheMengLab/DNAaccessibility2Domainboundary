#!/bin/bash

chrid=1
delta=0.2
cd temp
bash do.sh 
cd ..
#cp /media/group/2b2676b5-76e1-42af-864b-2152cf8da195/20201210/code/c/Nucleosome_model/segment_sample/HiC/simulation/Hi-C_highresolution/K562/10kb_resolution_intrachromosomal/compartment/compartment_assign/clustering_H3K4me3_assign/chr_10kb/assign${chrid}_10kb.dat .
#cp /home/group/code/c/Nucleosome_model/segment_sample/HiC/simulation/Hi-C_highresolution/K562/10kb_resolution_intrachromosomal/compartment/compartment_assign/clustering_H3K4me3_assign/chr_10kb/assign${chrid}_10kb.dat .
statenum=`nl ./temp/contact_top100.dat | tail -n 1 | awk '{print $1}'`
awk '{print 1}' ./temp/contact_top100.dat > assign${chrid}_10kb.dat
#echo -e ../test.dat '\n' $statenum '\n' test.dat '\n' score.dat | ./getarrowhead_maxscore_nodark.o
#echo -e ../test.dat '\n' ${statenum} '\n' assign${chrid}_10kb.dat '\n' test.dat '\n' score.dat | ./getarrowhead_maxscore_nodark_darkassign.o 
echo -e ./temp/contact_top100.dat '\n' ${statenum} '\n' assign${chrid}_10kb.dat '\n' 100 '\n' test_topline.dat '\n' score_topline.dat | ./getarrowhead_maxscore_nodark_darkassign_topline.o
#Input filename for original data:
#Input the dimension of matrix:
#Input the filename for compartassign(1 col):
#Input filename for arrowhead output:
#Input the filename for score list:


#echo -e ../test.dat '\n' 5136 '\n' test.dat | ./getarrowhead.o 
##Input filename for original data:
##Input the dimension of matrix:
##Input filename for output:

#echo -e score.dat '\n' score_statis.dat | ./getaverage.o
echo -e score_topline.dat '\n' assign${chrid}_10kb.dat '\n' score_statis.dat | ./getaverage_darkassign.o

cutoff=${delta}
cat score_statis.dat

echo -e score_topline.dat '\n' 10 '\n' 0 '\n' peakid_delta.dat '\n' test.dat | ./gethighpeak_scorebar.o

awk -v CUTOFF=${cutoff} '{if($2>CUTOFF) print $1,$2}' peakid_delta.dat > targetpeakid.dat

rm test_topline.dat



