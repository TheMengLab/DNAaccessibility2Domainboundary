#!/bin/bash

echo -e temp.dat '\n' chr22_10kb.KRnorm '\n' 10 '\n' test.dat | ./getcontactmatrix_norm.o 
#Input the filename for original data:
#Input the filename for norm list:
#Input the interval for this dataset(in the unit of kb):
#Input the filename for block interaction:

echo -e temp.dat '\n' chr22_10kb.KRnorm '\n' 10 '\n' 100 '\n' test_top100.dat | ./getcontactmatrix_norm_topline.o 
#Input the filename for original data:
#Input the filename for norm list:
#Input the interval for this dataset(in the unit of kb):
#Input the value for top line:
#Input the filename for block interaction:



