#!/bin/bash

chrid=1

bash do.sh ${chrid}
cd arrowhead/
bash do.sh ${chrid}
cd ../
