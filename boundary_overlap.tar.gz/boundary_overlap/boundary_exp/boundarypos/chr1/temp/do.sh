#!/bin/bash

chrid=1

sid=0
eid=500
dir=../../../Hi-Cdata/chr${chrid}/

cp ${dir}/chr${chrid}_10kb.KRnorm .
sed -i "s/NaN/0/g" chr${chrid}_10kb.KRnorm

awk -v ID=${id} -v SID=${sid} -v EID=${eid} '{if(($1>SID*1000000)&&($1<EID*1000000)&&($2>SID*1000000)&&($2<EID*1000000)) print $1-SID*1000000,$2-SID*1000000,$3}' ${dir}/chr${chrid}_10kb.RAWobserved > temp.dat


echo -e temp.dat '\n' chr${chrid}_10kb.KRnorm '\n' 10 '\n' 100 '\n' contact_top100.dat | ./getcontactmatrix_norm_topline.o

rm temp.dat


